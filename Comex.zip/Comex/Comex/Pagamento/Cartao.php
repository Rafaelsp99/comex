<?php
namespace Rafael\Comex\Pagamento;
use Rafael\Comex\interfaces\Pagamentomeio;

Class Cartao implements PagamentoMeio

{

    public function processarPagto(): bool
    {
        echo "Em processamento.." . PHP_EOL;

        sleep(6);

        $limite = rand(0,1);

        try
        {
            if ($limite===0)
            {
                throw new \Exception("Compra Recusada");

            }
        }

        catch (\Exception $e)
        {
            echo "". $e->getMessage() . PHP_EOL;
            return false;

        }

        echo "APROVADA!" . PHP_EOL;
        return true;
    }
}