<?php
namespace Rafael\Comex\Pagamento;
use Rafael\Comex\interfaces\Pagamentomeio;

Class Boleto implements PagamentoMeio

{

    public function processarPagto(): bool
    {
        echo "Em processamento.." . PHP_EOL;

        sleep(10);
        echo "Pagamento concluído". PHP_EOL;
        return true;
    }

}