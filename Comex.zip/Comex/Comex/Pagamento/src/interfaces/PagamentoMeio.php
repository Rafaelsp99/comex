<?php

namespace Rafael\Comex\Interfaces;

interface PagamentoMeio
{
    public function processarPagto(): bool;    
}
