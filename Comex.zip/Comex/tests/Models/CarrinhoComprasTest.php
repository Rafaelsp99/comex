<?php

namespace Rafael\Comex\Testes;

use PHPUnit\Framework\TestCase;
use CarrinhoDeCompras;
use Produto;
interface PagamentoMeio{}

Class PIX implements PagamentoMeio
{
    public function processarPagto(): bool
    {
        return true;
    }
}

class PIXrecusadoMock implements PagamentoMeio
{
    public function processarPagto(): bool
    {
        return false;
    }
}
class CarrinhoTest extends TestCase
{
    public function testValorTotalCorreto()
    {
        $carrinho1 = new CarrinhoDeCompras;
        ( new Produto("bola de futebol", 100.00, 2));        

        $this->assertEquals(100.00, $carrinho1->calculaTotal());
    }
}

