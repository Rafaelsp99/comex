<?php

namespace Rafael\Comex\Tests;
use PHPUnit\Framework\TestCase;
use Pedido;
use Produto;
use Cliente;
use CarrinhoDeCompras;



 class PedidoTest extends TestCase
{
    public function testAdicionarProduto(float $addProduto , float $qtd_estoque )
    {
        try {
            if ($addProduto < 0) {
                throw new \InvalidArgumentException('A quantidade  não pode ser negativa.');
            }
        } catch (\Exception $erro) {
            echo $erro->getMessage() . PHP_EOL;
            return;
        }
        $this->  $addProduto;
    }
    public function testPedidoNomeCorreto()
    {
        $pedido1 = new Pedido ("Furadeira", 250.00, 100);
       $cliente1= new Cliente ("RAFAEL SILVA DE PAULA" , "16 991497430", "rafelsp99@hotmail.com", "Rua: Bahia 925 Franca SP");
        $this->assertEquals("Furadeira", $pedido1->getProduto());
        $this->assertEquals("Furadeira", $cliente1->validaNome("RAFAEL SILVA DE PAULA" ));

        $this->assertEquals("rafelsp99@hotmail.com", $cliente1->getEmail());
    }
    
}
