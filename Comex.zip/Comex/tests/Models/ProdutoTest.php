<?php

namespace Rafael\Comex\Tests;
use PHPUnit\Framework\TestCase;
use Produto;


 class ProdutoTest extends TestCase
{
    public function testAdicionarProduto(float $addProduto , float $qtd_estoque )
    {
        try {
            if ($addProduto < 0) {
                throw new \InvalidArgumentException('A quantidade  não pode ser negativa.');
            }
        } catch (\Exception $erro) {
            echo $erro->getMessage() . PHP_EOL;
            return;
        }
        $this->  $addProduto;
    }
    public function testNomeCorretoProduto()
    {
        $produto1 = new Produto ("Furadeira", 250.00, 100);

        $this->assertEquals("Furadeira", $produto1->getNome());
    }
    public function testPrecoCorreto()
    {
        $produto1 = new Produto("Furadeira", 250.00, 100);

        $this->assertEquals(250.00, $produto1->getPreco());
    }

}
