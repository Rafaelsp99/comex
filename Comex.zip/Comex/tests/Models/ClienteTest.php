<?php

namespace Rafael\Comex\Testes;

use PHPUnit\Framework\TestCase;
use Cliente;

class ClienteTest extends TestCase
{
    public function testCelularFormatoCorreto()
    {
        $cliente1 = new Cliente("RAFAEL SILVA DE PAULA" , "16 991497430", "rafelsp99@hotmail.com", "Rua: Bahia 925 Franca SP");

        $this->assertEquals("(16) 94714-0300", $cliente1->getCelularvalidar("(16) 94714-0300"));
    }
}